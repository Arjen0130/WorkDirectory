var axios= require('../axios');


const getters = {

  todoItems: (state) => {
    return state.todoItems
  }

};

export default getters
