const state = {

  todoItems: []

};

export default state
