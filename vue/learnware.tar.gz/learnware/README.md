# Learnware


##  To get started:

     git clone https://git.coding.net/mengning/learnware.git
     cd learnware
     npm install
     npm run dev

