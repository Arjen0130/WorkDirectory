module.exports ={
  mongodb : "mongodb://localhost/starter"
}
